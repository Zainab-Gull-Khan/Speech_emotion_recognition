let emotionHistory = [];
let timeLabels = [];
let sessionSeconds = 0;
let timerInterval;
let chart;
let isRecording = false;
let globalStream;
let analysisInterval;

// ── TIMER ──────────────────────────────────────
function startTimer() {
    timerInterval = setInterval(() => {
        sessionSeconds++;
        let mins = String(Math.floor(sessionSeconds / 60)).padStart(2, '0');
        let secs = String(sessionSeconds % 60).padStart(2, '0');
        document.getElementById('timer').textContent = `Session: ${mins}:${secs}`;
    }, 1000);
}

// ── CHART ──────────────────────────────────────
function initChart() {
    const ctx = document.getElementById('emotionChart').getContext('2d');
    chart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: 'Emotion Over Time',
                data: [],
                borderColor: '#4ecca3',
                backgroundColor: 'rgba(78,204,163,0.1)',
                tension: 0.4,
                fill: true
            }]
        },
        options: {
            animation: { duration: 300 },
            scales: {
                y: {
                    ticks: {
                        callback: val => ['Bored','Excited','Neutral','Question'][val] || ''
                    },
                    min: 0, max: 3
                }
            }
        }
    });
}

// ── RECORD ONE CHUNK AND SEND TO MODEL ─────────
function recordChunk() {
    return new Promise((resolve) => {
        const mimeType = MediaRecorder.isTypeSupported('audio/webm')
            ? 'audio/webm' : 'audio/ogg';

        const recorder = new MediaRecorder(globalStream, { mimeType });
        const chunks = [];

        recorder.ondataavailable = e => chunks.push(e.data);
        recorder.onstop = async () => {
            const blob = new Blob(chunks, { type: mimeType });
            const formData = new FormData();
            formData.append('audio', blob, 'recording.webm');

            try {
                const res = await fetch('http://127.0.0.1:5000/predict', {
                    method: 'POST',
                    body: formData
                });
                if (!res.ok) throw new Error(`Server error: ${res.status}`);
                const data = await res.json();
                resolve(data);
            } catch (err) {
                console.error('Prediction error:', err);
                resolve(null);
            }
        };

        recorder.start();
        // Record for 3 seconds then send
        setTimeout(() => recorder.stop(), 3000);
    });
}

// ── CONTINUOUS ANALYSIS LOOP ───────────────────
async function startAnalysisLoop() {
    while (isRecording) {
        const data = await recordChunk();
        if (data && isRecording) {
            updateUI(data);
        }
        // Small gap between chunks
        await new Promise(r => setTimeout(r, 500));
    }
}

// ── START / STOP TOGGLE ────────────────────────
async function toggleRecording() {
    const btn = document.getElementById('recordBtn');

    if (!isRecording) {
        // START
        try {
            globalStream = await navigator.mediaDevices.getUserMedia({ audio: true });

            if (!chart) { initChart(); startTimer(); }

            isRecording = true;
            btn.textContent = '⏹️ Stop';
            btn.classList.add('recording');
            document.getElementById('teacher-response').textContent =
                '🎙️ Listening... speak naturally!';

            // Start continuous loop
            startAnalysisLoop();

        } catch (err) {
            console.error('Mic error:', err);
            document.getElementById('teacher-response').textContent =
                '⚠️ Microphone access denied.';
        }

    } else {
        // STOP
        isRecording = false;
        globalStream.getTracks().forEach(t => t.stop());
        btn.textContent = '🎙️ Start Speaking';
        btn.classList.remove('recording');
        document.getElementById('teacher-response').textContent =
            'Session paused. Click Start Speaking to continue.';
    }
}

// ── UPDATE UI ──────────────────────────────────
function updateUI(data) {
    const badge = document.getElementById('emotion-badge');
    badge.textContent = `Emotion: ${data.emotion.toUpperCase()}`;
    badge.className = `emotion-badge ${data.emotion}`;

    document.getElementById('confidence').textContent =
        `Confidence: ${data.confidence}%`;
    document.getElementById('engagement').textContent =
        `Engagement: ${data.engagement}`;
    document.getElementById('teacher-response').textContent =
        data.response;

    emotionHistory.push(data.emotion);
    timeLabels.push(`${sessionSeconds}s`);

    const emotionIndex = ['bored','excited','neutral','question']
        .indexOf(data.emotion);
    chart.data.labels = timeLabels;
    chart.data.datasets[0].data.push(emotionIndex);
    chart.update();
}

// ── END SESSION ────────────────────────────────
function endSession() {
    clearInterval(timerInterval);

    if (isRecording) {
        isRecording = false;
        globalStream.getTracks().forEach(t => t.stop());
        document.getElementById('recordBtn').textContent = '🎙️ Start Speaking';
        document.getElementById('recordBtn').classList.remove('recording');
    }

    const counts = {};
    emotionHistory.forEach(e => counts[e] = (counts[e] || 0) + 1);
    const dominant = Object.entries(counts).sort((a,b) => b[1]-a[1])[0];
    const total = emotionHistory.length;
    const highEngage = (counts['excited']||0) + (counts['question']||0);
    const engPct = total ? Math.round(highEngage / total * 100) : 0;

    document.getElementById('report').style.display = 'block';
    document.getElementById('report-content').innerHTML = `
        <p>⏱️ Session Duration: ${document.getElementById('timer').textContent}</p>
        <p>🎯 Total Predictions: ${total}</p>
        <p>🏆 Dominant Emotion: ${dominant ? dominant[0].toUpperCase() : '--'}</p>
        <p>📊 Engagement Rate: ${engPct}%</p>
        <p>😴 Bored: ${counts['bored']||0} times</p>
        <p>😊 Excited: ${counts['excited']||0} times</p>
        <p>😐 Neutral: ${counts['neutral']||0} times</p>
        <p>🤔 Question: ${counts['question']||0} times</p>
    `;
}