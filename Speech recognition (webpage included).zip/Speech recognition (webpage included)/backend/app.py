from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
from tensorflow.keras.layers import Layer
import librosa
import numpy as np
import tempfile
import os
import pickle
import random

app = Flask(__name__)
CORS(app)

# ── ATTENTION LAYER — must be defined before loading model ──
class AttentionLayer(Layer):
    def build(self, input_shape):
        self.W = self.add_weight(shape=(input_shape[-1], 1),
                                  initializer='random_normal', trainable=True)
        super(AttentionLayer, self).build(input_shape)
    def call(self, x):
        score = tf.nn.tanh(tf.matmul(x, self.W))
        weights = tf.nn.softmax(score, axis=1)
        return tf.reduce_sum(x * weights, axis=1)

# ── LOAD MODEL AND LABEL ENCODER ───────────────────────────
print("Loading model...")
model = tf.keras.models.load_model(
    '../model/ser_dual_model.h5',
    custom_objects={'AttentionLayer': AttentionLayer}
)

with open('../model/labels.pkl', 'rb') as f:
    labels = pickle.load(f)

from sklearn.preprocessing import LabelEncoder
le = LabelEncoder()
le.fit(labels)
EMOTIONS = le.classes_.tolist()

MAX_PAD_LEN = 174
N_MFCC = 40
print("✅ Model loaded! Emotions:", EMOTIONS)

# ── MFCC EXTRACTION ────────────────────────────────────────
def extract_mfcc(audio, sr):
    mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
    if mfcc.shape[1] < MAX_PAD_LEN:
        mfcc = np.pad(mfcc, ((0,0),(0, MAX_PAD_LEN - mfcc.shape[1])))
    else:
        mfcc = mfcc[:, :MAX_PAD_LEN]
    return mfcc

# ── CHATBOT RESPONSES ──────────────────────────────────────
responses = {
    'bored': [
        "Let me try explaining this differently!",
        "How about we look at a real world example?",
        "Let's take a quick break and come back stronger!"
    ],
    'excited': [
        "Love the energy! Let's dive even deeper.",
        "Great enthusiasm! Ready for something more challenging?",
        "You're on fire! Let's keep this momentum going."
    ],
    'neutral': [
        "Are you following along okay?",
        "Feel free to ask if anything needs clarification.",
        "Shall we move on or would you like me to recap?"
    ],
    'question': [
        "It seems like something's unclear — what can I help with?",
        "Great question energy! What would you like me to explain?",
        "I sense some confusion — let's break this down together."
    ]
}

@app.route('/predict', methods=['POST'])
def predict():
    audio_file = request.files['audio']

    # Save with original extension
    with tempfile.NamedTemporaryFile(suffix='.wav', delete=False) as tmp:
        audio_file.save(tmp.name)
        tmp_path = tmp.name

    try:
        # librosa can handle webm/wav/ogg automatically
        audio, sr = librosa.load(tmp_path, sr=22050, duration=3.0, mono=True)
    except Exception as e:
        os.unlink(tmp_path)
        return jsonify({'error': f'Audio processing failed: {str(e)}'}), 500
    finally:
        if os.path.exists(tmp_path):
            os.unlink(tmp_path)

    mfcc = extract_mfcc(audio, sr)
    mfcc = (mfcc - mfcc.mean()) / (mfcc.std() + 1e-8)
    mfcc = np.expand_dims(mfcc.T, axis=0)

    emotion_probs, engagement_probs = model.predict(mfcc)
    emotion_probs = emotion_probs[0]
    engagement_probs = engagement_probs[0]

    emotion = EMOTIONS[np.argmax(emotion_probs)]
    confidence = float(np.max(emotion_probs)) * 100
    engagement = 'High' if np.argmax(engagement_probs) == 1 else 'Low'
    response = random.choice(responses[emotion])

    return jsonify({
        'emotion': emotion,
        'confidence': round(confidence, 1),
        'response': response,
        'engagement': engagement
    })
if __name__ == '__main__':
    app.run(debug=True, port=5000)