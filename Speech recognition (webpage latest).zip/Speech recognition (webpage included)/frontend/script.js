// ── GLOBAL STATE ────────────────────────────────
let currentMode = 'classroom';
let isSessionActive = false;
let isPaused = false;
let sessionSeconds = 0;
let timerInterval;
let analysisLoopRunning = false;   // FIX: was a setInterval causing overlapping calls
let analysisIntervalMs = 3000;
let globalMediaStream;
let emotionHistory = [];
let timeLabels = [];
let timelineChart;
let doughnutChart;
let emotionCounts = {};
let interventions = 0;
let peakEmotion = { emotion: 'neutral', count: 0 };
let backendConnected = false;

// ── BACKEND CONNECTION TEST ────────────────────
async function testBackendConnection() {
    try {
        console.log('🔍 Testing backend connection...');
        const res = await fetch('http://127.0.0.1:5000/health', { signal: AbortSignal.timeout(3000) });
        if (res.ok) {
            console.log('✅ Backend connected!');
            backendConnected = true;
            return true;
        }
    } catch (err) {
        console.warn('❌ Backend not reachable:', err.message);
    }
    backendConnected = false;
    return false;
}

// ── INITIALIZATION ─────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 EduSense Pro Initializing...');
    initTimelineChart();
    initDoughnutChart();
    updateModeUI();
    setTimeout(testBackendConnection, 1500);
});

// ── MODE SWITCHING ─────────────────────────────
function switchMode(mode) {
    currentMode = mode;
    document.querySelectorAll('.nav-tab').forEach(tab => tab.classList.remove('active'));
    document.getElementById(`tab-${mode}`)?.classList.add('active');
    document.querySelectorAll('.mode-content').forEach(panel => panel.classList.remove('active'));
    document.getElementById(`mode-${mode}`)?.classList.add('active');
    updateModeUI();
}

function updateModeUI() {
    const titles = {
        classroom: '📚 Classroom Mode',
        exam: '📝 Exam Mode',
        language: '🗣️ Language Coach',
        specialed: '🎯 Special Education'
    };
    const descriptions = {
        classroom: 'Real-time engagement tracking and adaptive responses',
        exam: 'Stress monitoring and proctor alerts',
        language: 'Pronunciation feedback and emotional coaching',
        specialed: 'Emotion recognition training and self-reflection'
    };
    const titleEl = document.getElementById('modeTitle')?.querySelector('h2');
    if (titleEl) titleEl.textContent = titles[currentMode] || '';
    const descEl = document.getElementById('modeDescription');
    if (descEl) descEl.textContent = descriptions[currentMode] || '';
}

// ── SESSION MANAGEMENT ─────────────────────────
async function toggleSession() {
    if (!isSessionActive) await startSession();
    else endSession();
}

async function startSession() {
    console.log('🎙️ Starting session...');

    // FIX: Don't hard-block on backend. Warn but still allow mic + UI to start.
    const connected = await testBackendConnection();
    if (!connected) {
        addAlert('warning', '⚠️ Backend not reachable (http://127.0.0.1:5000). Start app.py first. Retrying in background...');
        // Retry silently every 5s in case backend starts later
        const retryTimer = setInterval(async () => {
            const ok = await testBackendConnection();
            if (ok) {
                clearInterval(retryTimer);
                addAlert('success', '✅ Backend connected!');
            }
        }, 5000);
        return; // Cannot record without backend — return early but keep UI responsive
    }

    try {
        globalMediaStream = await navigator.mediaDevices.getUserMedia({
            // Change to:
audio: { sampleRate: 16000, channelCount: 1, echoCancellation: false, noiseSuppression: false, autoGainControl: false }
        });
        console.log('✅ Microphone access granted');

        isSessionActive = true;
        isPaused = false;
        sessionSeconds = 0;
        emotionHistory = [];
        timeLabels = [];
        emotionCounts = {};
        interventions = 0;
        peakEmotion = { emotion: 'neutral', count: 0 };

        const btn = document.getElementById('btnStartStop');
        if (btn) {
            btn.innerHTML = '<span class="btn-icon">⏹️</span> Stop Session';
            btn.classList.add('recording');
        }
        const pauseBtn = document.getElementById('btnPause');
        if (pauseBtn) {
            pauseBtn.disabled = false;
            pauseBtn.innerHTML = '<span class="btn-icon">⏸️</span> Pause';
        }
        document.querySelector('.status-dot')?.classList.add('active');
        startTimer();
        addAlert('info', 'Session started');
        startAnalysisLoop();
    } catch (error) {
        console.error('❌ Microphone access denied:', error);
        addAlert('warning', '⚠️ Microphone access required. Please allow mic in your browser.');
    }
}

function pauseSession() {
    isPaused = !isPaused;
    const btn = document.getElementById('btnPause');
    if (isPaused) {
        if (btn) btn.innerHTML = '<span class="btn-icon">▶️</span> Resume';
    } else {
        if (btn) btn.innerHTML = '<span class="btn-icon">⏸️</span> Pause';
    }
}

function endSession() {
    if (!isSessionActive) return;
    clearInterval(timerInterval);
    analysisLoopRunning = false; // FIX: signal the async loop to stop
    if (globalMediaStream) globalMediaStream.getTracks().forEach(t => t.stop());
    isSessionActive = false;
    isPaused = false;
    const startBtn = document.getElementById('btnStartStop');
    if (startBtn) {
        startBtn.innerHTML = '<span class="btn-icon">🎙️</span> Start Session';
        startBtn.classList.remove('recording');
    }
    const pauseBtn = document.getElementById('btnPause');
    if (pauseBtn) pauseBtn.disabled = true;
    document.querySelector('.status-dot')?.classList.remove('active');
    generateReport();
}

// ── TIMER ──────────────────────────────────────
function startTimer() {
    clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        sessionSeconds++;
        const m = String(Math.floor(sessionSeconds / 60)).padStart(2, '0');
        const s = String(sessionSeconds % 60).padStart(2, '0');
        const indicator = document.querySelector('.session-indicator span:last-child');
        if (indicator) indicator.textContent = `Session: ${m}:${s}`;
        const dur = document.getElementById('statDuration');
        if (dur) dur.textContent = `${m}:${s}`;
    }, 1000);
}

// ── AUDIO RECORDING via MediaRecorder (replaces deprecated ScriptProcessor) ──
// FIX: createScriptProcessor is deprecated and broken in many modern browsers.
// MediaRecorder is the correct, supported Web API for capturing mic audio.
function recordChunk(stream, durationMs) {
    return new Promise((resolve, reject) => {
        // Prefer audio/wav, fall back to webm which Flask can handle via librosa
        const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
            ? 'audio/webm;codecs=opus'
            : 'audio/webm';

        let recorder;
        try {
            recorder = new MediaRecorder(stream, { mimeType });
        } catch (e) {
            return reject(new Error('MediaRecorder not supported: ' + e.message));
        }

        const chunks = [];
        recorder.ondataavailable = (e) => { if (e.data.size > 0) chunks.push(e.data); };
        recorder.onstop = () => {
            const blob = new Blob(chunks, { type: mimeType });
            resolve(blob);
        };
        recorder.onerror = (e) => reject(e.error);

        recorder.start();
        setTimeout(() => {
            if (recorder.state !== 'inactive') recorder.stop();
        }, durationMs);
    });
}

async function recordAndAnalyze() {
    if (!globalMediaStream) return null;
    try {
        const blob = await recordChunk(globalMediaStream, analysisIntervalMs);
        const ext = blob.type.includes('webm') ? 'webm' : 'wav';
        const formData = new FormData();
        formData.append('audio', blob, `recording.${ext}`);
        const res = await fetch('http://127.0.0.1:5000/predict', {
            method: 'POST',
            body: formData,
            signal: AbortSignal.timeout(10000)  // 10s timeout guard
        });
        if (!res.ok) throw new Error(`Server responded ${res.status}`);
        return await res.json();
    } catch (err) {
        console.error('recordAndAnalyze error:', err.message);
        return null;
    }
}

// ── ANALYSIS LOOP ─────────────────────────────
// FIX: Old code used setInterval(loop, 3000) where loop itself takes 3s → overlapping calls.
// New approach: sequential async loop — each iteration waits for the previous to finish.
async function startAnalysisLoop() {
    if (analysisLoopRunning) return; // prevent double-start
    analysisLoopRunning = true;
    console.log('🔄 Analysis loop started');

    while (analysisLoopRunning && isSessionActive) {
        if (!isPaused) {
            const data = await recordAndAnalyze();
            if (data && isSessionActive && !isPaused) {
                processAnalysisResult(data);
            }
        } else {
            // While paused, just wait a bit before checking again
            await new Promise(r => setTimeout(r, 500));
        }
    }

    console.log('🛑 Analysis loop stopped');
}

// ── PROCESS RESULTS ────────────────────────────
function processAnalysisResult(data) {
    const emotion = data.emotion || 'neutral';
    const confidence = data.confidence || 0;
    const engagement = data.engagement || 'Low';
    emotionHistory.push({ emotion, confidence, engagement, timestamp: sessionSeconds });
    timeLabels.push(`${sessionSeconds}s`);
    emotionCounts[emotion] = (emotionCounts[emotion] || 0) + 1;
    if (emotionCounts[emotion] > peakEmotion.count) {
        peakEmotion = { emotion, count: emotionCounts[emotion] };
    }
    updateMetrics(emotion, confidence, engagement);
    updateTimelineChart(emotion);
    updateDoughnutChart();
    updateModeSpecificUI(data);
    checkAlerts(emotion, confidence);
}

// ── METRICS UPDATE ─────────────────────────────
function updateMetrics(emotion, confidence, engagement) {
    const attn = engagement === 'High' ? 85 : engagement === 'Medium' ? 60 : 30;
    const eng  = engagement === 'High' ? 90 : engagement === 'Medium' ? 55 : 25;
    const set  = (id, val) => { const el = document.getElementById(id); if (el) el.textContent = val; };
    const bar  = (id, w)   => { const el = document.getElementById(id); if (el) el.style.width = w; };

    set('metricAttention', `${attn}%`);  bar('attentionBar',  `${attn}%`);
    set('metricEngagement', `${eng}%`);  bar('engagementBar', `${eng}%`);

    const confusion = ['frustrated','sad','fearful','disgusted'].includes(emotion)
        ? Math.min(95, 100 - confidence + 20)
        : Math.max(5,  100 - confidence - 20);
    const stress = ['angry','fearful','frustrated'].includes(emotion)
        ? Math.min(95, confidence + 10)
        : Math.max(5,  100 - confidence - 30);

    set('metricConfusion', `${confusion}%`); bar('confusionBar', `${confusion}%`);
    set('metricStress',    `${stress}%`);    bar('stressBar',    `${stress}%`);
    set('statPeakEmotion', peakEmotion.emotion);
    set('statAvgEngagement', `${eng}%`);
    set('statInterventions', interventions);
}

// ── MODE-SPECIFIC UI ──────────────────────────
function updateModeSpecificUI(data) {
    const emotion    = data.emotion    || 'neutral';
    const confidence = data.confidence || 0;
    if      (currentMode === 'classroom') updateClassroomUI(emotion, data);
    else if (currentMode === 'exam')      updateExamUI(emotion, confidence);
    else if (currentMode === 'language')  updateLanguageUI(emotion, data);
    else if (currentMode === 'specialed') updateSpecialEdUI(emotion, confidence);
}

function updateClassroomUI(emotion, data) {
    const icons = {
        excited:'🤩', happy:'😊', neutral:'😐', sad:'😢',
        frustrated:'😤', fearful:'😨', angry:'😠', surprised:'😲',
        disgusted:'🤢', calm:'😌'
    };
    const moodIcon = document.getElementById('moodIcon');
    if (moodIcon) moodIcon.textContent = icons[emotion] || '😐';
    const currentState = document.getElementById('currentState');
    if (currentState) currentState.textContent = emotion.charAt(0).toUpperCase() + emotion.slice(1);
    const teacherMsg = document.getElementById('teacherMessage');
    if (teacherMsg) {
        const p = teacherMsg.querySelector('p');
        if (p) p.textContent = data.response || 'Let me adapt my teaching to help you.';
    }
}

function updateExamUI(emotion, confidence) {
    const stressLevel = ['fearful','angry','frustrated'].includes(emotion)
        ? Math.min(95, confidence + 15)
        : Math.max(5, 100 - confidence - 20);
    const sv = document.getElementById('stressValue');
    if (sv) sv.textContent = `${stressLevel}%`;
    const circle = document.getElementById('stressCircle');
    if (circle) {
        const circumference = 283;
        const offset = circumference - (stressLevel / 100) * circumference;
        circle.style.strokeDashoffset = offset;
        circle.style.stroke = stressLevel > 70 ? '#ef4444' : stressLevel > 40 ? '#f59e0b' : '#10b981';
    }
    if (stressLevel > 75) addAlert('warning', '🚨 High exam stress detected');
}

function updateLanguageUI(emotion, data) {
    const stars  = Math.ceil((data.confidence || 0) / 20);
    const starStr = '⭐'.repeat(Math.max(0, stars)) + '☆'.repeat(Math.max(0, 5 - stars));
    ['pronScore', 'fluencyScore', 'confidenceScore'].forEach(id => {
        const el = document.getElementById(id);
        if (el) el.textContent = starStr;
    });
}

function updateSpecialEdUI(emotion, confidence) {
    const key = emotion.charAt(0).toUpperCase() + emotion.slice(1);
    const el  = document.getElementById(`intensity${key}`);
    if (el) el.textContent = `${confidence}%`;
}

// ── CHARTS ─────────────────────────────────────
function initTimelineChart() {
    const ctx = document.getElementById('emotionTimeline')?.getContext('2d');
    if (!ctx) return;
    timelineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: [],
            datasets: [{
                data: [],
                borderColor: '#10b981',
                tension: 0.4,
                fill: true,
                backgroundColor: 'rgba(16,185,129,0.1)'
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    min: 0, max: 9,
                    ticks: {
                        callback: v =>
                            ['angry','calm','disgusted','excited','fearful','happy','neutral','sad','surprised'][v] || ''
                    }
                }
            },
            plugins: { legend: { display: false } }
        }
    });
}

function updateTimelineChart(emotion) {
    if (!timelineChart) return;
    const idx = { angry:0, calm:1, disgusted:2, excited:3, fearful:4, happy:5, neutral:6, sad:7, surprised:8 }[emotion] ?? 6;
    timelineChart.data.labels = timeLabels.slice(-20);
    timelineChart.data.datasets[0].data.push(idx);
    timelineChart.data.datasets[0].data = timelineChart.data.datasets[0].data.slice(-20);
    timelineChart.update();
}

function initDoughnutChart() {
    const ctx = document.getElementById('emotionDoughnut')?.getContext('2d');
    if (!ctx) return;
    doughnutChart = new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [],
            datasets: [{
                data: [],
                backgroundColor: [
                    '#ef4444','#06b6d4','#84cc16','#f59e0b',
                    '#8b5cf6','#10b981','#64748b','#3b82f6','#ec4899'
                ]
            }]
        },
        options: {
            plugins: {
                legend: { position: 'bottom', labels: { color: '#94a3b8', font: { size: 10 } } }
            }
        }
    });
}

function updateDoughnutChart() {
    if (!doughnutChart) return;
    doughnutChart.data.labels   = Object.keys(emotionCounts);
    doughnutChart.data.datasets[0].data = Object.values(emotionCounts);
    doughnutChart.update();
}

// ── ALERTS ─────────────────────────────────────
function addAlert(type, msg) {
    const list = document.getElementById('alertList');
    if (!list) return;
    const icons = { info:'ℹ️', warning:'⚠️', success:'✅' };
    list.innerHTML =
        `<div class="alert-item ${type}">${icons[type] || ''} ${msg}</div>` + list.innerHTML;
}

function checkAlerts(emotion, confidence) {
    if (['fearful','angry','frustrated'].includes(emotion) && confidence > 60) {
        addAlert('warning', `High ${emotion} detected`);
    }
}

// ── PROCTOR ────────────────────────────────────
function proctorIntervene() {
    interventions++;
    const el = document.getElementById('statInterventions');
    if (el) el.textContent = interventions;
    addAlert('warning', '🚨 Proctor intervention triggered');
}

function sendEncouragement() {
    addAlert('info', '💪 Encouragement sent to student');
}

// ── REPORT ─────────────────────────────────────
function generateReport() {
    const modal = document.getElementById('reportModal');
    if (!modal) return;
    const dur = document.getElementById('statDuration')?.textContent || '00:00';
    const html = `
        <h3>📋 Summary</h3>
        <p><strong>Mode:</strong> ${currentMode}</p>
        <p><strong>Duration:</strong> ${dur}</p>
        <p><strong>Peak Emotion:</strong> ${peakEmotion.emotion}</p>
        <p><strong>Total Samples:</strong> ${emotionHistory.length}</p>
        <p><strong>Interventions:</strong> ${interventions}</p>
    `;
    const content = document.getElementById('reportContent');
    if (content) content.innerHTML = html;
    modal.style.display = 'flex';
}

function closeReport() {
    const modal = document.getElementById('reportModal');
    if (modal) modal.style.display = 'none';
}

function downloadReport() { alert('PDF export coming soon!'); }

// ── SETTINGS ──────────────────────────────────
function toggleSettings() {
    const panel = document.getElementById('settingsPanel');
    if (!panel) return;
    panel.style.display = panel.style.display === 'none' ? 'block' : 'none';
}

// ── REFLECTION (Special Ed) ────────────────────
function recordReflection(emotion) {
    const last = emotionHistory[emotionHistory.length - 1]?.emotion || 'neutral';
    const expressed = document.getElementById('expressedEmotion');
    const detected  = document.getElementById('detectedEmotion');
    const result    = document.getElementById('matchResult');
    if (expressed) expressed.textContent = emotion;
    if (detected)  detected.textContent  = last;
    if (result) {
        const match = emotion === last;
        result.textContent = match ? '✅ Match!' : '🔄 Partial match – keep practicing!';
        result.style.color = match ? '#10b981' : '#f59e0b';
    }
}

// ── TIMELINE RANGE ────────────────────────────
// FIX: Old code used bare `event` global which throws ReferenceError in strict mode browsers.
// Pass the event explicitly from the onclick handler in HTML, or use currentTarget.
function setTimelineRange(range, btn) {
    document.querySelectorAll('.btn-timeline').forEach(b => b.classList.remove('active'));
    if (btn) btn.classList.add('active');
    const points = range === '5m' ? 50 : range === 'all' ? emotionHistory.length : 20;
    if (timelineChart) {
        timelineChart.data.labels = timeLabels.slice(-points);
        timelineChart.data.datasets[0].data = timelineChart.data.datasets[0].data.slice(-points);
        timelineChart.update();
    }
}

console.log('✅ script.js (fixed) fully loaded');