from flask import Flask, request, jsonify
from flask_cors import CORS
import tensorflow as tf
from keras.layers import Layer
import librosa
import numpy as np
import tempfile
import os
import pickle
import random

app = Flask(__name__)

# FIX: Explicit CORS config — allow all origins (including file:// and localhost).
# Default flask-cors can silently reject requests from browser file:// origins.
CORS(app, resources={r"/*": {"origins": "*"}}, supports_credentials=False)

# ── ATTENTION LAYER ──
class AttentionLayer(Layer):
    def __init__(self, **kwargs):
        super(AttentionLayer, self).__init__(**kwargs)

    def build(self, input_shape):
        self.W = self.add_weight(
            shape=(input_shape[-1], 1),
            initializer='random_normal',
            trainable=True
        )
        super(AttentionLayer, self).build(input_shape)

    def call(self, x):
        score = tf.nn.tanh(tf.matmul(x, self.W))
        weights = tf.nn.softmax(score, axis=1)
        return tf.reduce_sum(x * weights, axis=1)

    def get_config(self):
        return super(AttentionLayer, self).get_config()


# ── CONSTANTS ──
MAX_PAD_LEN = 300
N_MFCC      = 40
TARGET_SR   = 16000
DURATION    = 3.0

# ── LOAD MODEL ──
print("Loading model...")
BASE_DIR  = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, '..', 'model')

model_path = os.path.join(MODEL_DIR, 'ser_multi_dataset_model.h5')
label_path = os.path.join(MODEL_DIR, 'label_encoder.pkl')

print(f"Model path: {model_path}")
print(f"Label path: {label_path}")

model = None  # FIX: Don't exit(1) — keep server alive even if model missing

try:
    model = tf.keras.models.load_model(
        model_path,
        custom_objects={'AttentionLayer': AttentionLayer}
    )
    print("✅ Model loaded!")
except Exception as e:
    # FIX: Was exit(1) — that killed the Flask process silently.
    # Now we log the error and serve a graceful 503 from /predict.
    print(f"❌ Model load error: {e}")
    print("⚠️  Server will start but /predict will return 503 until model is available.")

try:
    with open(label_path, 'rb') as f:
        le = pickle.load(f)
    EMOTIONS = le.classes_.tolist()
    print("✅ Label encoder loaded:", EMOTIONS)
except Exception:
    EMOTIONS = ['angry', 'calm', 'disgusted', 'excited', 'fearful', 'happy', 'neutral', 'sad', 'surprised']
    print("⚠️  Using default emotions:", EMOTIONS)


# ── MFCC EXTRACTION ──
def extract_mfcc(audio, sr):
    mfcc = librosa.feature.mfcc(y=audio, sr=sr, n_mfcc=N_MFCC)
    if mfcc.shape[1] < MAX_PAD_LEN:
        mfcc = np.pad(mfcc, ((0, 0), (0, MAX_PAD_LEN - mfcc.shape[1])))
    else:
        mfcc = mfcc[:, :MAX_PAD_LEN]
    return mfcc.transpose()


# ── RESPONSES ──
responses = {
    'angry': [
        "I sense some frustration. Let's take a deep breath and work through this together.",
        "It's okay to feel frustrated. Let me explain this differently.",
        "I understand this can be challenging. Let's break it down step by step."
    ],
    'calm': [
        "You seem very relaxed. Ready to learn something new?",
        "Great focus! Shall we dive into the next topic?",
        "Your calm energy is perfect for learning. Let's continue."
    ],
    'disgusted': [
        "Something seems off. Would you like me to change my approach?",
        "I notice you might not be enjoying this. How can I help?",
        "Let's try a different angle that might work better for you."
    ],
    'excited': [
        "Love the energy! Let's dive even deeper.",
        "Great enthusiasm! Ready for something more challenging?",
        "You're on fire! Let's keep this momentum going."
    ],
    'fearful': [
        "Don't worry, we'll get through this together. Take your time.",
        "I understand this might feel overwhelming. Let's start with the basics.",
        "There's nothing to fear. I'm here to support your learning."
    ],
    'happy': [
        "Your positive energy is contagious! Let's keep learning.",
        "Great vibes! Ready for some interesting material?",
        "I'm glad you're enjoying this. Let's explore further!"
    ],
    'neutral': [
        "Are you following along okay?",
        "Feel free to ask if anything needs clarification.",
        "Shall we move on or would you like me to recap?"
    ],
    'sad': [
        "I notice you might be feeling down. Want to take a break?",
        "Learning can be tough sometimes. I'm here to help.",
        "It's okay to feel sad. Let's find something that lifts your spirits."
    ],
    'surprised': [
        "That seemed unexpected! Let me explain what just happened.",
        "Interesting reaction! Want me to elaborate?",
        "I see that surprised you! Let's explore that concept more."
    ]
}


@app.route('/predict', methods=['POST'])
def predict():
    # FIX: Return 503 gracefully if model never loaded
    if model is None:
        return jsonify({'error': 'Model not loaded. Check server logs.'}), 503

    if 'audio' not in request.files:
        return jsonify({'error': 'No audio file provided'}), 400

    audio_file = request.files['audio']

    # FIX: Detect suffix properly; support both wav and webm from MediaRecorder
    suffix = '.webm'
    if audio_file.filename and '.' in audio_file.filename:
        suffix = os.path.splitext(audio_file.filename)[1].lower()
    if suffix not in ('.wav', '.webm', '.ogg', '.mp4', '.m4a'):
        suffix = '.webm'  # safe fallback

    tmp_path = None
    try:
        with tempfile.NamedTemporaryFile(suffix=suffix, delete=False) as tmp:
            audio_file.save(tmp.name)
            tmp_path = tmp.name

        # librosa handles wav, webm, ogg, mp4 via ffmpeg under the hood
        audio, sr = librosa.load(tmp_path, sr=TARGET_SR, duration=DURATION, mono=True)

        target_len = int(TARGET_SR * DURATION)
        if len(audio) < target_len:
            audio = np.pad(audio, (0, target_len - len(audio)))
        else:
            audio = audio[:target_len]

        mfcc = extract_mfcc(audio, TARGET_SR)
        mfcc = (mfcc - mfcc.mean()) / (mfcc.std() + 1e-8)
        mfcc = np.expand_dims(mfcc, axis=0)

        results = model.predict(mfcc, verbose=0)
        emotion_probs    = results[0][0]
        engagement_probs = results[1][0]

        pred_idx   = int(np.argmax(emotion_probs))
        emotion    = EMOTIONS[pred_idx] if pred_idx < len(EMOTIONS) else 'neutral'
        confidence = float(emotion_probs[pred_idx]) * 100
        engagement = 'High' if np.argmax(engagement_probs) == 1 else 'Low'
        response   = random.choice(responses.get(emotion, responses['neutral']))

        return jsonify({
            'emotion':    emotion,
            'confidence': round(confidence, 1),
            'response':   response,
            'engagement': engagement
        })

    except Exception as e:
        print(f"Predict error: {e}")
        return jsonify({
            'emotion':    'unknown',
            'confidence': 0,
            'response':   'Unable to process audio.',
            'engagement': 'Low'
        }), 200  # return 200 so frontend still processes it

    finally:
        if tmp_path and os.path.exists(tmp_path):
            os.unlink(tmp_path)

    
@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status':       'healthy',
        'model_loaded': model is not None,
        'emotions':     EMOTIONS
    })


if __name__ == '__main__':
    os.environ['TF_CPP_MIN_LOG_LEVEL'] = '2'
    print("\n🚀 SERVER STARTING on http://127.0.0.1:5000\n")
    app.run(debug=True, host='127.0.0.1', port=5000)